﻿using System.Collections.Generic;
using YBFramework.Bridge.Data;

namespace YBFramework.Editor.Graph
{
    /// <summary>
    /// 负责绑定一个GraphAsset和一个CustomGraphView，并且操作GraphAsset的数据和CustomGraphView的显示。
    /// </summary>
    public sealed class GraphAssetDrawer
    {
        private GraphAsset m_GraphAsset;

        private CustomGraphView m_GraphView;

        /*private SerializedObject m_SO;

        private SerializedProperty m_NodeDataListProperty;*/

        private readonly List<BaseNodeDrawer> m_NodeDrawers = new();

        /*private int m_UndoGroupIndex;

        private bool m_IsModifyGraphAsset;*/

        public GraphAsset GetGraphAsset()
        {
            return m_GraphAsset;
        }

        public CustomGraphView GetGraphView()
        {
            return m_GraphView;
        }

        public IReadOnlyList<BaseNodeDrawer> GetNodeDrawers()
        {
            return m_NodeDrawers;
        }

        public void AddNodeDrawer(BaseNodeDrawer nodeDrawer)
        {
            m_NodeDrawers.Add(nodeDrawer);
        }

        public void RemoveNodeDrawer(BaseNodeDrawer nodeDrawer)
        {
            if (m_NodeDrawers.Remove(nodeDrawer))
            {
                nodeDrawer.ClearPortDrawers();
            }
        }

        public void ClearNodeDrawers()
        {
            foreach (BaseNodeDrawer nodeDrawer in m_NodeDrawers)
            {
                nodeDrawer.ClearPortDrawers();
                //如果存在对象池，需要释放每一个nodeDrawer
            }
            m_NodeDrawers.Clear();
        }

        public void DrawGraphView(GraphAsset graphAsset)
        {
            m_GraphAsset = graphAsset;
            //创建GraphView
            //m_GraphView = new CustomGraphView();
        }

        /*/// <summary>
        /// 在修改GraphAsset数据之前调用此方法，以便支持Undo，并且在修改完成后调用ApplyModifyGraphAsset方法。
        /// </summary>
        /// <param name="undoName">本次Undo名</param>
        /// <exception cref="InvalidOperationException">如果调用了一次这个方法，没调用应用修改将会抛出异常</exception>
        public void ModifyGraphAsset(string undoName)
        {
            if (m_IsModifyGraphAsset)
            {
                throw new InvalidOperationException("You have already called ModifyGraphAsset, please call ApplyModifyGraphAsset before calling ModifyGraphAsset again.");
            }
            m_IsModifyGraphAsset = true;
            Undo.IncrementCurrentGroup();
            m_UndoGroupIndex = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(undoName);
            Undo.RegisterCompleteObjectUndo(m_GraphAsset, undoName);
        }

        /// <summary>
        /// 应用修改GraphAsset数据，并且支持Undo。
        /// </summary>
        public void ApplyModifyGraphAsset()
        {
            if (m_IsModifyGraphAsset)
            {
                //TODO:是否要区分通过SerializedObject修改还是直接内存修改？
                // 通过SerializedObject修改会自己记录Undo，我需要通过UndoGroup区分
                EditorUtility.SetDirty(m_GraphAsset);
                Undo.CollapseUndoOperations(m_UndoGroupIndex);
                m_IsModifyGraphAsset = false;
            }
        }*/
    }
}