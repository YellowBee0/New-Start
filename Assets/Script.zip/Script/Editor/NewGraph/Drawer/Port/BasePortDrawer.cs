﻿using UnityEngine.UIElements;
using YBFramework.Bridge.Data;

namespace YBFramework.Editor.Graph
{
    public abstract class BasePortDrawer
    {
        public abstract BasePortData GetPortData();

        public abstract VisualElement GetPortContentView();

        public abstract PortView GetPortView();

        public abstract void DrawPortView(BasePortData portData);
    }
}