﻿using System.Collections.Generic;
using YBFramework.Bridge.Data;

namespace YBFramework.Editor.Graph
{
    /// <summary>
    /// 负责绑定一个NodeData和一个NodeView，并且操作NodeData的数据和NodeView的显示。
    /// </summary>
    public abstract class BaseNodeDrawer
    {
        private BaseNodeData m_NodeData;

        private NodeView m_NodeView;

        private readonly List<BasePortDrawer> m_PortDrawers = new();

        public BaseNodeData GetNodeData()
        {
            return m_NodeData;
        }

        public NodeView GetNodeView()
        {
            return m_NodeView;
        }

        public IReadOnlyList<BasePortDrawer> GetPortDrawers()
        {
            return m_PortDrawers;
        }

        public void AddPortDrawer(BasePortDrawer portDrawer)
        {
            m_PortDrawers.Add(portDrawer);
        }

        public void RemovePortDrawer(BasePortDrawer portDrawer)
        {
            m_PortDrawers.Remove(portDrawer);
        }
        
        public void ClearPortDrawers()
        {
            //如果存在对象池，需要释放每一个portDrawer
            m_PortDrawers.Clear();
        }

        public void DrawNodeView(BaseNodeData nodeData)
        {
            nodeData.InitializePortData();
            m_NodeData = nodeData;
            m_NodeView = OnDrawNodeView(nodeData);
        }

        protected abstract NodeView OnDrawNodeView(BaseNodeData nodeData);
    }
}