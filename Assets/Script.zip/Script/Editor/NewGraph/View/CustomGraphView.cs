﻿using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine.UIElements;

namespace YBFramework.Editor.NewGraph
{
    public sealed class CustomGraphView : GraphView
    {
        private string m_GUID;

        private readonly List<NodeView> m_Nodes = new();

        private readonly List<Port> m_CompatiblePorts = new();

        public CustomGraphView()
        {
            SetupZoom(ContentZoomer.DefaultMinScale, ContentZoomer.DefaultMaxScale);
            this.AddManipulator(new ContentDragger());
            this.AddManipulator(new SelectionDragger());
            this.AddManipulator(new RectangleSelector());
            GridBackground grid = new();
            grid.StretchToParentSize();
            Insert(0, grid);
            this.StretchToParentSize();
        }
        
        public string GetGUID()
        {
            return m_GUID;
        }

        public void AddNodeView(NodeView nodeView)
        {
            if (!m_Nodes.Contains(nodeView))
            {
                m_Nodes.Add(nodeView);
                AddElement(nodeView);
            }
        }

        public void RemoveNodeView(NodeView nodeView)
        {
            if (m_Nodes.Remove(nodeView))
            {
                nodeView.ClearPortViews();
                RemoveElement(nodeView);
            }
        }

        public void Initialize(string guid)
        {
            m_GUID = guid;
        }

        public override List<Port> GetCompatiblePorts(Port startPort, NodeAdapter nodeAdapter)
        {
            Direction direction = startPort.direction;
            m_CompatiblePorts.Clear();
            for (int i = 0; i < m_Nodes.Count; i++)
            {
                IReadOnlyList<PortView> portViews = m_Nodes[i].GetPortViews();
                for (int j = 0; j < portViews.Count; j++)
                {
                    PortView portView = portViews[j];
                    if (portView.direction != direction)
                    {
                        m_CompatiblePorts.Add(portView);
                    }
                }
            }
            return m_CompatiblePorts;
        }
    }
}