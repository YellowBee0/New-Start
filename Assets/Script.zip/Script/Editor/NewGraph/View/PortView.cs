﻿using System;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;

namespace YBFramework.Editor.NewGraph
{
    public sealed class PortView : Port
    {
        private static readonly List<Edge> m_Edges = new();

        private int m_PortID;

        private Action<Edge> m_OnPortViewConnect;

        private Action<Edge> m_OnPortViewDisconnect;

        public PortView(Direction direction, Capacity capacity) : base(Orientation.Horizontal, direction, capacity, null)
        {
        }

        public int GetPortID()
        {
            return m_PortID;
        }
        
        public void ClearConnections()
        {
            m_Edges.Clear();
            m_Edges.AddRange(connections);
            foreach (Edge edge in m_Edges)
            {
                Disconnect(edge);
            }
        }

        public void Initialize(int portID, string portViewName, Color color, EdgeConnector<Edge> edgeViewConnector)
        {
            m_PortID = portID;
            portName = portViewName;
            portColor = color;
            m_EdgeConnector = edgeViewConnector;
            this.AddManipulator(edgeViewConnector);
        }

        public void RegisterOnPortViewConnect(Action<Edge> onPortViewConnect)
        {
            m_OnPortViewConnect += onPortViewConnect;
        }

        public void UnregisterOnPortViewConnect(Action<Edge> onPortViewConnect)
        {
            m_OnPortViewConnect -= onPortViewConnect;
        }

        public void RegisterOnPortViewDisconnect(Action<Edge> onPortViewDisconnect)
        {
            m_OnPortViewDisconnect += onPortViewDisconnect;
        }

        public void UnregisterOnPortViewDisconnect(Action<Edge> onPortViewDisconnect)
        {
            m_OnPortViewDisconnect -= onPortViewDisconnect;
        }

        public override void Connect(Edge edge)
        {
            base.Connect(edge);
            m_OnPortViewConnect?.Invoke(edge);
        }

        public override void Disconnect(Edge edge)
        {
            base.Disconnect(edge);
            m_OnPortViewDisconnect?.Invoke(edge);
        }
    }
}