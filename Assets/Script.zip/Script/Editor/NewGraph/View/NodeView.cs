﻿using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;

namespace YBFramework.Editor.NewGraph
{
    public sealed class NodeView : Node
    {
        private int m_NodeID;

        private readonly List<PortView> m_PortViews = new();

        public void Initialize(int nodeID, string nodeName, Vector2 position)
        {
            m_NodeID = nodeID;
            title = nodeName;
            SetPosition(new Rect(position, Vector2.zero));
            m_PortViews.Clear();
        }

        public int GetNodeID()
        {
            return m_NodeID;
        }
        
        public IReadOnlyList<PortView> GetPortViews()
        {
            return m_PortViews;
        }
        
        public void AddPortContentView(VisualElement portContentView, PortView portView)
        {
            portContentView.style.borderBottomColor = Color.black;
            portContentView.style.borderBottomWidth = .2f;
            if (portView.direction == Direction.Input)
            {
                inputContainer.Add(portContentView);
            }
            else
            {
                outputContainer.Add(portContentView);
            }
            m_PortViews.Add(portView);
        }

        public void RemovePortContentView(VisualElement portContentView, PortView portView)
        {
            if (portView.direction == Direction.Input)
            {
                inputContainer.Remove(portContentView);
            }
            else
            {
                outputContainer.Remove(portContentView);
            }
            m_PortViews.Remove(portView);
        }
        
        public void ClearPortViews()
        {
            for (int i = 0; i < m_PortViews.Count; i++)
            {
                PortView portView = m_PortViews[i];
                portView.ClearConnections();
                //如果池化了，需要释放每一个portView
            }
            inputContainer.Clear();
            outputContainer.Clear();
            m_PortViews.Clear();
        }

        public void RefreshPortContainerDisplay()
        {
            inputContainer.style.display = inputContainer.childCount == 0 ? DisplayStyle.None : DisplayStyle.Flex;
            outputContainer.style.display = outputContainer.childCount == 0 ? DisplayStyle.None : DisplayStyle.Flex;
        }
    }
}